/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        premium: {
          bg1: '#FAF6EF', // Warm Ivory
          bg2: '#F4EDE3', // Luxury Cream
          bg3: '#EEE1D2', // Soft Champagne Beige
          bg4: '#E7D5C0', // Premium Nude Beige
          
          primary1: '#4A2525', // Deep Cocoa Maroon
          primary2: '#6B3434', // Muted Wine Brown
          primary3: '#8A5A4A', // Rose Brown
          primary4: '#A9785C', // Luxury Terracotta Nude
          
          accent1: '#C7A76C', // Muted Champagne Gold
          accent2: '#B8955F', // Antique Soft Gold
          accent3: '#D8C29D', // Light Luxury Gold
          accent4: '#E6D6B8', // Soft Gold Cream
          
          floral1: '#D9B6A3', // Dusty Peach Rose
          floral2: '#CFA6A6', // Muted Blush Rose
          floral3: '#B88A8A', // Vintage Rose
          floral4: '#F1DDD2', // Light Floral Peach
          
          text1: '#1C1715', // Premium Dark Text
          text2: '#4E3A34', // Soft Brown Text
          text3: '#7A6257', // Muted Secondary Text
        }
      },
      fontFamily: {
        heading: ['Playfair Display', 'serif'],
        sans: ['Outfit', 'Inter', 'sans-serif'],
      },
      animation: {
        'spin-slow': 'spin 15s linear infinite',
        'marquee': 'marquee 25s linear infinite',
      },
      keyframes: {
        marquee: {
          '0%': { transform: 'translateX(0%)' },
          '100%': { transform: 'translateX(-100%)' },
        }
      },
      boxShadow: {
        'luxury': '0 20px 40px rgba(74, 37, 37, 0.08)',
        'luxury-hover': '0 30px 60px rgba(74, 37, 37, 0.12)',
        'glow': '0 0 25px rgba(199, 167, 108, 0.16)',
        'card': '0 18px 45px rgba(74, 37, 37, 0.10)',
      }
    },
  },
  plugins: [],
}

