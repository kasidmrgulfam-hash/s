import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './Layout';
import Home from './pages/Home';
import WholesalePolicy from './pages/WholesalePolicy';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="wholesale-policy" element={<WholesalePolicy />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
