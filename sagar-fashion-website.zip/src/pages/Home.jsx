import React from 'react';
import Hero from '../components/Hero';
import ProductGrid from '../components/ProductGrid';
import YouTubeSection from '../components/YouTubeSection';
import TrustSection from '../components/TrustSection';
import ProcessSection from '../components/ProcessSection';
import InfoSection from '../components/InfoSection';
import FAQSection from '../components/FAQSection';
import ScrollReveal from '../components/ScrollReveal';

const FloralDivider = () => (
  <div className="w-full overflow-hidden leading-none relative z-10 -mt-[1px]">
    <svg className="relative block w-[calc(100%+1.3px)] h-[50px] md:h-[80px]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
      <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" className="fill-premium-bg1"></path>
    </svg>
  </div>
);

const Home = () => {
  return (
    <>
      <Hero />
      <FloralDivider />
      
      <ScrollReveal y={40}>
        <TrustSection />
      </ScrollReveal>
      
      <div className="bg-premium-bg2 py-10">
        <ScrollReveal y={60}>
          <ProductGrid />
        </ScrollReveal>
      </div>
      
      <ScrollReveal y={40}>
        <YouTubeSection />
      </ScrollReveal>
      
      <ScrollReveal y={40}>
        <ProcessSection />
      </ScrollReveal>
      
      <ScrollReveal y={40}>
        <InfoSection />
      </ScrollReveal>
      
      <ScrollReveal y={40}>
        <FAQSection />
      </ScrollReveal>
    </>
  );
};

export default Home;
