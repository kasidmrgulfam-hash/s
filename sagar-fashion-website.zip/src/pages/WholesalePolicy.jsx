import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Package, AlertCircle, Truck, RefreshCw, MessageCircle, FileText, Send } from 'lucide-react';
import ScrollReveal from '../components/ScrollReveal';

const PolicyCard = ({ icon, title, text }) => (
  <div className="bg-[#FFFDF8] border border-[rgba(199,167,108,0.28)] p-8 rounded-[2rem] flex flex-col items-center text-center group hover:-translate-y-2 transition-all duration-500 hover:shadow-card">
    <div className="w-16 h-16 rounded-full bg-premium-bg3 flex items-center justify-center text-premium-primary3 mb-5 group-hover:scale-110 group-hover:bg-premium-primary1 group-hover:text-premium-bg1 transition-all duration-500 shadow-inner">
      {icon}
    </div>
    <h3 className="font-heading font-bold text-xl text-premium-text1 mb-3">{title}</h3>
    <p className="text-sm text-premium-text2 leading-relaxed font-light">{text}</p>
  </div>
);

const TimelineStep = ({ number, title, desc, icon }) => (
  <div className="flex gap-6 relative group">
    {/* Line */}
    <div className="absolute left-7 top-14 bottom-[-2rem] w-px bg-premium-accent1 group-last:hidden"></div>
    {/* Icon */}
    <div className="w-14 h-14 shrink-0 rounded-full bg-premium-primary1 border border-premium-accent1 flex items-center justify-center text-premium-bg1 font-bold z-10 shadow-sm group-hover:bg-premium-primary2 group-hover:border-transparent transition-colors duration-300">
      {number}
    </div>
    {/* Content */}
    <div className="pb-10 pt-2">
      <div className="flex items-center gap-2 mb-2">
        {icon && <span className="text-premium-primary3">{icon}</span>}
        <h4 className="font-heading font-bold text-lg text-premium-text1">{title}</h4>
      </div>
      <p className="text-sm text-premium-text2 font-light">{desc}</p>
    </div>
  </div>
);

const WholesalePolicy = () => {
  return (
    <div className="pt-32 pb-20 relative bg-premium-bg1">
      
      {/* Hero Banner */}
      <section className="container mx-auto px-4 md:px-8 mb-24 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="bg-gradient-to-br from-premium-bg3 to-premium-bg4 rounded-[3rem] p-12 md:p-20 text-center relative overflow-hidden shadow-sm border border-premium-accent3"
        >
          {/* Subtle soft overlay texture */}
          <div className="absolute inset-0 opacity-[0.05] bg-[url('data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%238A5A4A\' fill-opacity=\'1\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')]"></div>
          
          <span className="relative z-10 text-premium-primary1 font-bold tracking-[0.3em] uppercase text-[10px] mb-6 block border border-premium-primary4/30 inline-block px-4 py-1.5 rounded-full bg-white/50">Official Guidelines</span>
          <h1 className="relative z-10 font-heading text-4xl md:text-6xl lg:text-7xl font-bold mb-6 text-premium-text1 drop-shadow-sm">Wholesale Policy</h1>
          <p className="relative z-10 text-lg md:text-xl text-premium-text2 max-w-2xl mx-auto font-light leading-relaxed">
            Simple, transparent and trusted wholesale process for boutique owners, resellers and shopkeepers.
          </p>
        </motion.div>
      </section>

      {/* Policy Grid */}
      <section className="container mx-auto px-4 md:px-8 mb-32 relative z-10">
        <ScrollReveal>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
            <PolicyCard icon={<ShieldCheck size={28} />} title="Wholesale Only" text="No single piece retail. Bulk buyers only."/>
            <PolicyCard icon={<Package size={28} />} title="MOQ 24 Pieces" text="1 design = 4 colors = 1 set. Minimum 6 sets."/>
            <PolicyCard icon={<AlertCircle size={28} />} title="Prepaid Orders" text="No COD. Orders are processed after payment confirmation."/>
            <PolicyCard icon={<Truck size={28} />} title="Global Shipping" text="Courier 6–7 days, transport 4–5 days. Worldwide delivery available."/>
            <PolicyCard icon={<RefreshCw size={28} />} title="Damage Support" text="Return/replacement support only for damaged pieces."/>
            <PolicyCard icon={<ShieldCheck size={28} />} title="Quality Checked" text="Pieces are checked before dispatch to ensure quality."/>
            <PolicyCard icon={<Package size={28} />} title="Premium Packing" text="Every suit is packed in premium pouch bags, set-wise."/>
            <PolicyCard icon={<MessageCircle size={28} />} title="Dedicated Support" text="Direct WhatsApp connection for order updates."/>
          </div>
        </ScrollReveal>
      </section>

      {/* Timeline Process */}
      <section className="container mx-auto px-4 md:px-8 mb-32 relative z-10">
        <ScrollReveal y={40}>
          <div className="bg-white/80 backdrop-blur-md rounded-[3rem] p-10 md:p-16 shadow-card border border-premium-accent3 max-w-5xl mx-auto flex flex-col md:flex-row gap-16">
            <div className="flex-1">
              <span className="text-[10px] text-premium-primary4 uppercase tracking-widest font-bold mb-3 block">Simple & Transparent</span>
              <h2 className="font-heading font-bold text-3xl md:text-4xl text-premium-text1 mb-6">How to Order</h2>
              <p className="text-premium-text2 font-light leading-relaxed mb-8">
                We've streamlined our ordering process to be as fast and effortless as possible, so you can focus on selling.
              </p>
            </div>
            <div className="flex-1">
              <TimelineStep number="1" title="Select Collection" desc="Browse our website or YouTube channel to choose designs." />
              <TimelineStep number="2" title="Add to Bulk Inquiry" desc="Use the website Cart to build your bulk requirement list." />
              <TimelineStep number="3" title="Send WhatsApp Inquiry" desc="Submit your list via our automated WhatsApp button." />
              <TimelineStep number="4" title="Confirm Availability" desc="Our team verifies stock and sends the final wholesale invoice." />
              <TimelineStep number="5" title="Prepaid Payment" desc="Transfer funds securely via bank transfer or UPI." />
              <TimelineStep number="6" title="Fast Dispatch" desc="Orders are dispatched by courier or transport." />
            </div>
          </div>
        </ScrollReveal>
      </section>

      {/* Specific Callout section */}
      <section className="container mx-auto px-4 md:px-8 relative z-10">
        <ScrollReveal y={30}>
          <div className="maroon-gradient rounded-[3rem] p-10 md:p-16 text-center max-w-4xl mx-auto shadow-luxury relative overflow-hidden">
            <div className="absolute -top-20 -right-20 w-64 h-64 bg-premium-accent1 rounded-full blur-[80px] opacity-20 pointer-events-none"></div>
            
            <h2 className="font-heading text-3xl md:text-5xl font-bold text-premium-bg1 mb-4">Need Latest Catalog?</h2>
            <p className="text-premium-bg4 mb-10 max-w-lg mx-auto font-medium text-lg opacity-90">
              Get our complete wholesale catalog with high-resolution photos and pricing directly on your phone.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <a href="https://wa.me/917984572633?text=Hello%20Sagar%20Fashion,%20please%20send%20me%20your%20latest%20wholesale%20catalog." target="_blank" rel="noreferrer" className="hover-target bg-premium-bg1 text-premium-primary1 hover:text-premium-primary2 px-10 py-5 rounded-full font-bold transition-all flex items-center justify-center gap-3 shadow-lg hover:shadow-xl hover:bg-premium-bg3 hover:scale-105 border border-premium-accent1/50">
                <FileText size={20} className="text-premium-primary3" />
                Request Catalog on WhatsApp
              </a>
            </div>
          </div>
        </ScrollReveal>
      </section>

    </div>
  );
};

export default WholesalePolicy;
