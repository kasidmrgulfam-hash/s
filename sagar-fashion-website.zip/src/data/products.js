export const products = [
  {
    id: 'p1',
    name: 'Heavy Zarkan Work Bridal Suit',
    category: 'Bridal Wear',
    fabric: 'Premium Net & Silk',
    stitching: 'Semi-Stitched',
    priceRange: '₹1800 - ₹2200',
    moq: 4,
    colors: ['Red', 'Maroon', 'Pink', 'Gold'],
    image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    description: 'Exquisite bridal suit with heavy zarkan and embroidery work.'
  },
  {
    id: 'p2',
    name: 'Designer Pakistani Concept Suit',
    category: 'Pakistani Suits',
    fabric: 'Georgette',
    stitching: 'Semi-Stitched',
    priceRange: '₹1400 - ₹1700',
    moq: 4,
    colors: ['Dusty Rose', 'Mint Green', 'Powder Blue', 'Lavender'],
    image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    description: 'Elegant pakistani style straight suit with heavy net dupatta.'
  },
  {
    id: 'p3',
    name: 'Premium Flared Anarkali',
    category: 'Anarkali',
    fabric: 'Fox Georgette',
    stitching: 'Fully Stitched (XL)',
    priceRange: '₹2500 - ₹3000',
    moq: 4,
    colors: ['Wine', 'Navy Blue', 'Bottle Green', 'Black'],
    image: 'https://images.unsplash.com/photo-1583391733958-d25e07fac0fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    description: 'Royal flared anarkali suit perfect for wedding guests.'
  },
  {
    id: 'p4',
    name: 'Heavy Handwork Sharara Suit',
    category: 'Sharara / Gharara',
    fabric: 'Organza & Silk',
    stitching: 'Semi-Stitched',
    priceRange: '₹2200 - ₹2800',
    moq: 4,
    colors: ['Mustard', 'Rani Pink', 'Teal', 'Purple'],
    image: 'https://images.unsplash.com/photo-1617260846664-d4b68ef50f4d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    description: 'Trendy sharara with intricate handwork and gota patti.'
  },
  {
    id: 'p5',
    name: 'Cotton Casual Printed Plazo Set',
    category: 'Cotton Casual',
    fabric: 'Pure Cotton',
    stitching: 'Readymade',
    priceRange: '₹800 - ₹1100',
    moq: 4,
    colors: ['Yellow', 'Peach', 'Sky Blue', 'Light Green'],
    image: 'https://images.unsplash.com/photo-1564585222527-c2777a5bc6cb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    description: 'Daily wear comfortable cotton plazo suits for home sellers.'
  },
  {
    id: 'p6',
    name: 'Boutique Special Party Wear Gown',
    category: 'Gown Collection',
    fabric: 'Heavy Satin & Net',
    stitching: 'Semi-Stitched',
    priceRange: '₹3000 - ₹4000',
    moq: 4,
    colors: ['Rose Gold', 'Silver Grey', 'Emerald', 'Ruby Red'],
    image: 'https://images.unsplash.com/photo-1590412200988-a436970781fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    description: 'Luxurious party wear gown with premium embellishments.'
  }
];

export const categories = [
  'All',
  'Bridal Wear',
  'Party Wear',
  'Pakistani Suits',
  'Anarkali',
  'Sharara / Gharara',
  'Plazo Suits',
  'Cotton Casual',
  'Zarkan Work',
  'Gown Collection'
];
