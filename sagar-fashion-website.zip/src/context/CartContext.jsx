import React, { createContext, useContext, useState, useEffect } from 'react';

const CartContext = createContext();

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState(() => {
    const savedCart = localStorage.getItem('sagar_wholesale_cart');
    return savedCart ? JSON.parse(savedCart) : [];
  });
  
  const [isCartOpen, setIsCartOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('sagar_wholesale_cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id ? { ...item, sets: item.sets + 1 } : item
        );
      }
      return [...prevCart, { ...product, sets: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId) => {
    setCart((prevCart) => prevCart.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId, sets) => {
    if (sets < 1) return;
    setCart((prevCart) =>
      prevCart.map(item =>
        item.id === productId ? { ...item, sets } : item
      )
    );
  };

  const clearCart = () => setCart([]);

  const totalSets = cart.reduce((total, item) => total + item.sets, 0);
  const totalPieces = cart.reduce((total, item) => total + (item.sets * item.moq), 0);
  const isMoqMet = totalPieces >= 24; // 6 sets = 24 pieces minimum

  return (
    <CartContext.Provider value={{
      cart,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      totalSets,
      totalPieces,
      isMoqMet,
      isCartOpen,
      setIsCartOpen
    }}>
      {children}
    </CartContext.Provider>
  );
};
