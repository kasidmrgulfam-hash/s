import React from 'react';
import { ReactLenis } from 'lenis/react';
import { Outlet } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CartDrawer from './components/CartDrawer';
import CustomCursor from './components/CustomCursor';
import AnimatedBackground from './components/AnimatedBackground';

const Layout = () => {
  return (
    <ReactLenis root options={{ lerp: 0.08, duration: 1.5, smoothTouch: true }}>
      <div className="min-h-screen flex flex-col font-sans hide-cursor">
        <AnimatedBackground />
        <CustomCursor />
        <Header />
        <main className="flex-grow">
          <Outlet />
        </main>
        <Footer />
        <CartDrawer />
      </div>
    </ReactLenis>
  );
};

export default Layout;
