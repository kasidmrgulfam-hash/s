import React, { useEffect, useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { Award, Users, ShoppingBag, TrendingUp, Gem, MapPin, Star } from 'lucide-react';

const CountUp = ({ end, duration = 2, inView }) => {
  const [count, setCount] = useState(0);
  
  useEffect(() => {
    if (!inView) return;
    
    let startTime;
    let animationFrame;
    
    const animate = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const progress = timestamp - startTime;
      const percentage = Math.min(progress / (duration * 1000), 1);
      
      // Easing function (easeOutQuart)
      const easeProgress = 1 - Math.pow(1 - percentage, 4);
      setCount(Math.floor(easeProgress * end));
      
      if (percentage < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };
    
    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [end, duration, inView]);

  return <span>{count}</span>;
};

const TrustCard = ({ icon, number, suffix, title, delay }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <motion.div 
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.6, delay, ease: "easeOut" }}
      className="bg-[rgba(255,253,248,0.8)] border border-[rgba(199,167,108,0.25)] p-8 rounded-[2rem] text-center group hover:-translate-y-2 transition-all duration-500 hover:shadow-card"
    >
      <div className="w-16 h-16 mx-auto rounded-full bg-premium-bg3 flex items-center justify-center text-premium-primary3 mb-6 group-hover:bg-premium-primary1 group-hover:text-premium-bg1 transition-all duration-500 shadow-inner">
        {icon}
      </div>
      <h3 className="font-heading font-bold text-4xl text-premium-primary1 mb-2 flex items-center justify-center">
        <CountUp end={number} inView={isInView} />
        {suffix}
      </h3>
      <p className="text-sm text-premium-text2 font-semibold uppercase tracking-wider">{title}</p>
    </motion.div>
  );
};

const TrustSection = () => {
  return (
    <section id="trust" className="py-24 relative overflow-hidden bg-premium-bg1">
      
      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-premium-primary4 font-bold tracking-[0.2em] uppercase text-[10px] mb-4 block">Our Legacy</span>
          <h2 className="font-heading text-3xl md:text-5xl font-bold text-premium-text1 mb-6">Why Boutique Owners Trust Sagar Fashion</h2>
          <p className="text-premium-primary2 text-lg italic font-heading opacity-90">
            "Hum sirf suits nahi dete, boutique owners aur resellers ke liye fast-moving premium collection provide karte hain jisse unka business grow hota hai."
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto mb-16">
          <TrustCard icon={<Award size={28} />} number={20} suffix="+" title="Years Experience" delay={0} />
          <TrustCard icon={<Users size={28} />} number={135} suffix="K+" title="YouTube Family" delay={0.1} />
          <TrustCard icon={<ShoppingBag size={28} />} number={200} suffix="+" title="Monthly Bulk Buyers" delay={0.2} />
          <TrustCard icon={<TrendingUp size={28} />} number={5} suffix="+" title="New Weekly Designs" delay={0.3} />
        </div>

        <div className="max-w-5xl mx-auto flex flex-wrap justify-center gap-4">
          {['Premium Quality Fabrics', 'Fast-Selling Designs', 'Premium Pouch Packing', 'India & International Shipping', 'Wholesale-Only Pricing', 'High Repeat Customer Rate'].map((badge, idx) => (
            <span key={idx} className="bg-premium-bg2 border border-[rgba(199,167,108,0.35)] text-premium-text2 text-xs md:text-sm font-semibold px-5 py-2.5 rounded-full shadow-sm flex items-center gap-2">
              <Star size={14} className="text-premium-primary4" />
              {badge}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustSection;
