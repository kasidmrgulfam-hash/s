import React from 'react';
import { useCart } from '../context/CartContext';
import { ShoppingBag } from 'lucide-react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import ImageWithFallback from './ImageWithFallback';

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();
  
  // 3D Tilt Logic
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const mouseXSpring = useSpring(x, { damping: 25, stiffness: 150 });
  const mouseYSpring = useSpring(y, { damping: 25, stiffness: 150 });
  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["8deg", "-8deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-8deg", "8deg"]);

  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    x.set(mouseX / width - 0.5);
    y.set(mouseY / height - 0.5);
  };
  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div 
      style={{ rotateX, rotateY, perspective: 1200 }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      whileHover={{ y: -10 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="bg-[rgba(255,253,248,0.9)] backdrop-blur-xl border border-[rgba(199,167,108,0.25)] shadow-[0_18px_45px_rgba(74,37,37,0.10)] rounded-[1.5rem] overflow-hidden hover:shadow-[0_25px_50px_rgba(74,37,37,0.15)] transition-all duration-500 group flex flex-col h-full"
    >
      {/* Image Container */}
      <div className="relative aspect-[3/4] overflow-hidden bg-premium-bg2 flex-shrink-0 border-b border-[rgba(199,167,108,0.15)]">
        <ImageWithFallback 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full group-hover:scale-110 transition-transform duration-[2s] ease-out" 
        />
        
        <div className="absolute inset-0 bg-gradient-to-t from-premium-primary1/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>

        {/* Top Badges */}
        <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
          <span className="bg-premium-floral4 text-premium-primary2 text-[9px] font-bold px-3 py-1.5 rounded-full shadow-sm uppercase tracking-[0.2em] border border-[rgba(199,167,108,0.3)]">
            {product.category}
          </span>
        </div>
        
        {/* Subtle corner soft peach accent */}
        <div className="absolute -top-4 -right-4 w-20 h-20 bg-premium-floral1/20 rounded-full blur-[15px] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>

        {/* Hover Action */}
        <div className="absolute bottom-5 left-5 right-5 translate-y-12 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500 ease-out flex gap-2 z-20">
          <button 
            onClick={() => addToCart(product)}
            className="hover-target w-full bg-premium-primary1 text-premium-bg1 border border-[rgba(199,167,108,0.3)] font-bold py-3.5 rounded-xl hover:bg-premium-primary2 transition-all flex items-center justify-center gap-2 text-[10px] uppercase tracking-[0.15em] shadow-lg"
          >
            <ShoppingBag size={14} />
            Add to Inquiry
          </button>
        </div>
      </div>

      {/* Content - Glassy Info Area */}
      <div className="p-6 bg-gradient-to-b from-transparent to-premium-bg1 flex-1 flex flex-col">
        <h3 className="font-heading font-bold text-premium-text1 text-xl leading-tight mb-2 line-clamp-1 group-hover:text-premium-primary3 transition-colors">{product.name}</h3>
        
        <div className="flex flex-col gap-1.5 text-[10px] text-premium-text3 mb-5 font-semibold tracking-widest uppercase">
          <p><span className="text-premium-primary4 pr-1">Fabric:</span> {product.fabric}</p>
          <p><span className="text-premium-primary4 pr-1">Type:</span> {product.stitching}</p>
        </div>

        <div className="flex items-center justify-between mb-2 mt-auto pt-4 border-t border-[rgba(199,167,108,0.15)]">
          <span className="text-[9px] bg-premium-primary1 text-premium-bg1 border border-premium-accent1 px-3 py-1.5 rounded-full font-bold tracking-[0.2em] uppercase">
            MOQ {product.moq} Pcs
          </span>
          <div className="text-right">
            <p className="font-heading font-bold text-2xl text-premium-primary2 leading-none drop-shadow-sm">
              {product.priceRange}
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;
