import React, { useState } from 'react';
import ProductCard from './ProductCard';
import { Search } from 'lucide-react';
import { products as productData } from '../data/products';

const categories = ["All", "Bridal", "Party Wear", "Pakistani", "Anarkali"];

const ProductGrid = () => {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredProducts = activeCategory === "All" 
    ? productData 
    : productData.filter(product => product.category === activeCategory);

  return (
    <section id="collection" className="py-24 relative bg-premium-bg2">
      <div className="container mx-auto px-4 md:px-8 max-w-7xl relative z-10">
        
        <div className="text-center mb-16">
          <span className="text-premium-primary4 font-bold tracking-[0.2em] uppercase text-[10px] mb-4 block">Exclusive Range</span>
          <h2 className="font-heading text-4xl md:text-5xl font-bold text-premium-text1 mb-6">Latest Wholesale Collection</h2>
          <p className="text-premium-text2 max-w-2xl mx-auto font-light text-lg">Premium set-wise suits packed for boutiques and resellers.</p>
        </div>

        {/* Categories and Search */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-12">
          
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`hover-target px-6 py-2.5 rounded-full text-xs uppercase tracking-wider font-semibold transition-all duration-300 relative overflow-hidden border ${
                  activeCategory === category 
                    ? 'bg-premium-primary1 text-premium-bg1 border-premium-accent1 shadow-md' 
                    : 'bg-premium-bg1 border-premium-accent3 text-premium-text2 hover:border-premium-primary4 hover:text-premium-primary3'
                }`}
              >
                <span className="relative z-10">{category}</span>
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-64 group">
            <input 
              type="text" 
              placeholder="Search designs..." 
              className="w-full bg-white/70 backdrop-blur-sm border border-premium-accent3 rounded-full py-2.5 pl-10 pr-4 text-sm focus:outline-none focus:border-premium-primary4 focus:ring-1 focus:ring-premium-primary4 transition-all shadow-sm text-premium-text1"
            />
            <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-premium-primary4 group-focus-within:text-premium-primary2 transition-colors" />
          </div>

        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
          {filteredProducts.map(product => (
            <div key={product.id} className="h-full">
              <ProductCard product={product} />
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

export default ProductGrid;
