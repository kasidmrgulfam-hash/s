import React from 'react';

const InfoSection = () => {
  return (
    <section className="py-24 relative bg-premium-bg2">
      <div className="container mx-auto px-4 md:px-8">
        <div className="bg-gradient-to-br from-premium-primary1 to-premium-primary2 rounded-[3rem] p-10 md:p-16 flex flex-col md:flex-row items-center justify-between gap-10 shadow-card overflow-hidden relative border border-premium-accent1/30">
          
          <div className="absolute top-0 right-0 w-64 h-64 bg-premium-accent1 rounded-full blur-[100px] opacity-10 pointer-events-none"></div>

          <div className="md:w-1/2 relative z-10">
            <span className="text-premium-accent1 font-bold tracking-[0.2em] uppercase text-[10px] mb-4 block">Store Location</span>
            <h2 className="font-heading text-3xl md:text-5xl font-bold text-premium-bg1 mb-6">Visit Our Surat Wholesale Outlet</h2>
            <p className="text-premium-bg3 font-light leading-relaxed mb-8 opacity-90 text-lg">
              Experience the premium quality of our fabrics firsthand. We welcome boutique owners to visit our dispatch center in Surat.
            </p>
            
            <div className="space-y-4 text-premium-bg4 font-light mb-8">
              <p className="flex items-start gap-3">
                <span className="text-premium-accent1 font-bold mt-1">Address:</span>
                Sagar Fashion, Textile Market Area, Ring Road, Surat, Gujarat 395002
              </p>
              <p className="flex items-start gap-3">
                <span className="text-premium-accent1 font-bold">Hours:</span>
                Mon - Sat: 10:00 AM - 8:00 PM
              </p>
            </div>

            <a 
              href="https://maps.app.goo.gl/BtfoceouyneA3Dx26" 
              target="_blank" 
              rel="noreferrer"
              className="hover-target inline-flex items-center gap-2 bg-transparent border border-premium-accent1 text-premium-bg1 px-8 py-3 rounded-full font-bold hover:bg-premium-bg1 hover:text-premium-primary1 transition-colors"
            >
              Get Directions
            </a>
          </div>

          <div className="md:w-1/2 w-full h-[300px] md:h-[400px] rounded-2xl overflow-hidden shadow-lg border border-[rgba(250,246,239,0.1)] relative z-10">
             <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d119066.41730260481!2d72.7410996160167!3d21.159462703816654!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be04e59411d1563%3A0xfe4558290938b042!2sSurat%2C%20Gujarat!5e0!3m2!1sen!2sin!4v1709664551381!5m2!1sen!2sin" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen="" 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Sagar Fashion Map Location"
                className="filter opacity-90 sepia-[20%] hue-rotate-[-10deg]"
              ></iframe>
          </div>

        </div>
      </div>
    </section>
  );
};

export default InfoSection;
