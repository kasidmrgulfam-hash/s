import React from 'react';

const AnimatedBackground = () => {
  // Generate random soft petals for floating background
  const petals = Array.from({ length: 15 }).map((_, i) => ({
    id: i,
    left: `${Math.random() * 100}vw`,
    top: `${Math.random() * 100}vh`,
    animationDelay: `${Math.random() * 15}s`,
    animationDuration: `${16 + Math.random() * 15}s`,
    scale: 0.4 + Math.random() * 0.6
  }));

  return (
    <div className="fixed inset-0 pointer-events-none z-[-1] overflow-hidden bg-gradient-to-br from-premium-bg1 via-premium-bg2 to-premium-bg3">
      
      {/* Soft Peach Floral Line Art Corner Decorations */}
      <div className="absolute top-[-5%] right-[-5%] w-[40vw] h-[40vw] opacity-[0.08] animate-rotate-slow">
        <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
          <path fill="none" stroke="#D9B6A3" strokeWidth="1" d="M100 0 C120 40 160 80 200 100 C160 120 120 160 100 200 C80 160 40 120 0 100 C40 80 80 40 100 0 Z" />
          <circle cx="100" cy="100" r="40" fill="none" stroke="#D9B6A3" strokeWidth="0.5"/>
          <circle cx="100" cy="100" r="60" fill="none" stroke="#D9B6A3" strokeWidth="0.5" strokeDasharray="4 4"/>
        </svg>
      </div>

      <div className="absolute bottom-[-10%] left-[-10%] w-[50vw] h-[50vw] opacity-[0.06] animate-rotate-slow" style={{ animationDirection: 'reverse' }}>
        <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
          <path fill="none" stroke="#D9B6A3" strokeWidth="1" d="M100 0 C120 40 160 80 200 100 C160 120 120 160 100 200 C80 160 40 120 0 100 C40 80 80 40 100 0 Z" />
        </svg>
      </div>

      {/* Blurred Soft Blobs for Depth */}
      <div className="absolute top-[20%] left-[-10%] w-[40vw] h-[40vw] rounded-full bg-premium-floral4/20 blur-[120px] animate-soft-drift-gold opacity-40"></div>
      <div className="absolute bottom-[10%] right-[10%] w-[50vw] h-[50vw] rounded-full bg-premium-bg4/30 blur-[150px] animate-soft-drift-gold opacity-50" style={{ animationDelay: '-5s' }}></div>
      <div className="absolute top-[50%] right-[20%] w-[25vw] h-[25vw] rounded-full bg-premium-accent4/30 blur-[100px] animate-gold-shimmer opacity-30"></div>

      {/* Floating Soft Champagne Petals */}
      {petals.map((petal) => (
        <div
          key={petal.id}
          className="absolute opacity-0 animate-floating-gold"
          style={{
            left: petal.left,
            top: petal.top,
            animationDelay: petal.animationDelay,
            animationDuration: petal.animationDuration,
            transform: `scale(${petal.scale})`
          }}
        >
          <svg viewBox="0 0 100 100" width="30" height="30" xmlns="http://www.w3.org/2000/svg">
            <path fill="url(#petalGrad)" d="M50 0C55 20 80 45 100 50C80 55 55 80 50 100C45 80 20 55 0 50C20 45 45 20 50 0Z" />
            <defs>
              <linearGradient id="petalGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#E6D6B8" stopOpacity="0.8" />
                <stop offset="50%" stopColor="#D8C29D" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#C7A76C" stopOpacity="0.2" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      ))}
    </div>
  );
};

export default AnimatedBackground;
