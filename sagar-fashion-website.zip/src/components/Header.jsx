import React, { useState, useEffect } from 'react';
import { ShoppingBag, Menu, X, Phone, CheckCircle, Diamond, Truck } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const Header = () => {
  const { totalSets, setIsCartOpen } = useCart();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'Collection', href: '/#collection' },
    { name: 'YouTube', href: '/#youtube' },
    { name: 'Why Trust Us', href: '/#trust' },
    { name: 'Wholesale Policy', href: '/wholesale-policy' },
  ];

  return (
    <>
      {/* Top Champagne Beige Announcement Bar */}
      <div className="bg-premium-bg3 text-premium-primary1 py-2 text-[10px] sm:text-[11px] font-bold tracking-[0.15em] uppercase relative z-50 overflow-hidden shadow-sm">
        <div className="container mx-auto px-4 flex flex-col sm:flex-row justify-center items-center gap-2 sm:gap-6 text-center relative z-10">
          <span className="flex items-center gap-1.5"><CheckCircle size={12} className="text-premium-accent2" /> Wholesale Only • MOQ 24 Pieces</span>
          <span className="hidden sm:flex items-center gap-1.5"><Diamond size={12} className="text-premium-accent2" /> 135K+ YouTube Family</span>
          <span className="hidden md:flex items-center gap-1.5"><Truck size={12} className="text-premium-accent2" /> India & International Shipping</span>
        </div>
      </div>

      {/* Main Sticky Navbar */}
      <header className={`sticky top-0 w-full z-40 transition-all duration-500 ${isScrolled ? 'bg-[rgba(250,246,239,0.82)] backdrop-blur-[18px] border-b border-[rgba(199,167,108,0.35)] py-3 shadow-luxury' : 'bg-transparent py-6'}`}>
        <div className="container mx-auto px-4 md:px-8 flex justify-between items-center">
          
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 cursor-pointer hover-target group">
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full border border-[rgba(199,167,108,0.35)] bg-premium-bg1 flex items-center justify-center text-premium-text1 font-heading font-bold text-xl md:text-2xl shadow-sm group-hover:bg-premium-bg3 transition-all duration-500 relative overflow-hidden">
              <span className="relative z-10">S</span>
            </div>
            <div className="flex flex-col">
              <h1 className="font-heading text-xl md:text-3xl font-bold text-premium-text1 leading-none tracking-tight transition-colors duration-300">
                Sagar Fashion
              </h1>
              <span className="text-[9px] md:text-xs text-premium-primary4 tracking-[0.2em] uppercase font-medium mt-0.5">
                Wholesale Surat
              </span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <motion.div key={link.name} whileHover={{ y: -2 }} transition={{ type: "spring", stiffness: 400, damping: 10 }}>
                <Link 
                  to={link.href}
                  className={`hover-target text-[11px] uppercase tracking-[0.1em] font-semibold transition-all duration-300 relative group py-2
                    ${location.pathname === link.href || (location.pathname === '/' && location.hash === link.href.substring(1)) ? 'text-premium-primary2' : 'text-premium-text2 hover:text-premium-primary2'}`}
                >
                  {link.name}
                  <span className={`absolute bottom-0 left-1/2 w-0 h-0.5 bg-premium-accent1 transition-all duration-300 group-hover:w-full group-hover:left-0 ${location.pathname === link.href ? 'w-full left-0 bg-premium-primary2' : ''}`}></span>
                </Link>
              </motion.div>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-4">
            <motion.a 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href="https://wa.me/917984572633" 
              target="_blank" 
              rel="noreferrer" 
              className="hover-target hidden md:flex items-center gap-2 text-[11px] uppercase tracking-[0.15em] font-bold text-premium-bg1 bg-premium-primary1 px-6 py-3 rounded-full shadow-luxury border border-premium-accent1 hover:bg-premium-primary2 hover:shadow-[0_0_25px_rgba(199,167,108,0.28)] transition-all group"
            >
              <Phone size={14} className="group-hover:-rotate-12 group-hover:scale-110 transition-transform text-premium-bg1" />
              WhatsApp Inquiry
            </motion.a>
            
            <motion.button 
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setIsCartOpen(true)}
              className="hover-target relative p-2.5 text-premium-text1 hover:text-premium-primary2 rounded-full transition-colors group bg-white/50 backdrop-blur-md border border-[rgba(199,167,108,0.35)]"
            >
              <ShoppingBag size={20} className="relative z-10 text-premium-primary2 group-hover:text-premium-primary1 transition-colors" />
              {totalSets > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-premium-primary1 text-premium-bg1 text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white z-20 shadow-sm animate-pulse">
                  {totalSets}
                </span>
              )}
            </motion.button>

            <button 
              className="hover-target lg:hidden p-2 text-premium-text1 relative z-[60]"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X size={24} className="text-premium-primary1" /> : <Menu size={24} className="text-premium-primary1" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu Full Screen Overlay */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="fixed inset-0 bg-premium-bg1/95 backdrop-blur-2xl z-50 lg:hidden flex flex-col justify-center items-center"
            >
              {/* Soft floral background inside menu */}
              <div className="absolute inset-0 opacity-[0.05] bg-[url('data:image/svg+xml,%3Csvg width=\'100\' height=\'100\' viewBox=\'0 0 100 100\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3z\' fill=\'%23CFA6A6\' fill-opacity=\'1\' fill-rule=\'evenodd\'/%3E%3C/svg%3E')]"></div>
              
              <nav className="flex flex-col items-center gap-8 relative z-10">
                {navLinks.map((link) => (
                  <Link 
                    key={link.name} 
                    to={link.href}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="font-heading text-3xl font-bold text-premium-text1 hover:text-premium-primary2 transition-colors"
                  >
                    {link.name}
                  </Link>
                ))}
                <a href="https://wa.me/917984572633" target="_blank" rel="noreferrer" className="flex items-center gap-2 text-premium-bg1 bg-premium-primary1 font-bold text-lg mt-6 px-8 py-4 rounded-full shadow-luxury border border-premium-accent1">
                  <Phone size={20} />
                  Inquiry on WhatsApp
                </a>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
    </>
  );
};

export default Header;
