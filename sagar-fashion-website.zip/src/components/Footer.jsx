import React from 'react';
import { Phone, MapPin, Mail, ArrowUp } from 'lucide-react';
import { Link } from 'react-router-dom';

const YoutubeIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"></path><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"></polygon></svg>
);

const InstagramIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
);

const FacebookIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
);

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-premium-bg2 border-t border-[rgba(199,167,108,0.25)] text-premium-text1 pt-20 pb-10 relative overflow-hidden">
      
      {/* Decorative top border */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-premium-bg3 via-premium-accent1 to-premium-bg3 opacity-40"></div>
      
      {/* Background glow */}
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-premium-floral4 rounded-full blur-[150px] opacity-20 pointer-events-none"></div>

      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Brand Col */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-full border border-[rgba(199,167,108,0.4)] bg-premium-bg1 flex items-center justify-center text-premium-primary1 font-heading font-bold text-xl shadow-sm">
                S
              </div>
              <div>
                <h3 className="font-heading text-2xl font-bold tracking-tight text-premium-primary1">Sagar Fashion</h3>
                <p className="text-[10px] text-premium-primary4 tracking-[0.2em] uppercase">Wholesale Surat</p>
              </div>
            </div>
            <p className="text-premium-text2 text-sm font-light leading-relaxed mb-6">
              Premium ethnic wear wholesale supplier from Surat. Trusted by boutique owners and resellers worldwide for fast-selling, high-margin collections.
            </p>
            <div className="flex gap-4 text-premium-primary2">
              <a href="https://youtube.com" className="w-10 h-10 rounded-full border border-[rgba(199,167,108,0.4)] flex items-center justify-center hover:bg-premium-primary1 hover:text-premium-bg1 hover:border-premium-primary1 transition-all">
                <YoutubeIcon />
              </a>
              <a href="https://instagram.com" className="w-10 h-10 rounded-full border border-[rgba(199,167,108,0.4)] flex items-center justify-center hover:bg-premium-primary1 hover:text-premium-bg1 hover:border-premium-primary1 transition-all">
                <InstagramIcon />
              </a>
              <a href="https://facebook.com" className="w-10 h-10 rounded-full border border-[rgba(199,167,108,0.4)] flex items-center justify-center hover:bg-premium-primary1 hover:text-premium-bg1 hover:border-premium-primary1 transition-all">
                <FacebookIcon />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-lg mb-6 text-premium-primary1">Quick Links</h4>
            <ul className="space-y-3 text-premium-text2 text-sm font-light">
              <li><a href="/#collection" className="hover:text-premium-primary2 transition-colors flex items-center gap-2"><span className="w-1 h-1 bg-premium-accent1 rounded-full"></span> Latest Collection</a></li>
              <li><Link to="/wholesale-policy" className="hover:text-premium-primary2 transition-colors flex items-center gap-2"><span className="w-1 h-1 bg-premium-accent1 rounded-full"></span> Wholesale Policy</Link></li>
              <li><a href="/#trust" className="hover:text-premium-primary2 transition-colors flex items-center gap-2"><span className="w-1 h-1 bg-premium-accent1 rounded-full"></span> Why Trust Us</a></li>
              <li><a href="/#youtube" className="hover:text-premium-primary2 transition-colors flex items-center gap-2"><span className="w-1 h-1 bg-premium-accent1 rounded-full"></span> YouTube Channel</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-bold text-lg mb-6 text-premium-primary1">Contact Us</h4>
            <ul className="space-y-4 text-premium-text2 text-sm font-light">
              <li className="flex items-start gap-3">
                <MapPin size={18} className="text-premium-accent2 shrink-0 mt-0.5" />
                <span>Textile Market Area, Ring Road, Surat, Gujarat 395002</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={18} className="text-premium-accent2 shrink-0" />
                <span>+91 79845 72633</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={18} className="text-premium-accent2 shrink-0" />
                <span>wholesale@sagarfashion.com</span>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="font-bold text-lg mb-6 text-premium-primary1">Get WhatsApp Updates</h4>
            <p className="text-premium-text2 text-sm font-light mb-4">Save our number and send a message to receive daily catalog updates on WhatsApp Status.</p>
            <a 
              href="https://wa.me/917984572633?text=Hello%20Sagar%20Fashion,%20please%20add%20me%20to%20your%20broadcast%20list." 
              target="_blank" 
              rel="noreferrer"
              className="w-full bg-[rgba(250,246,239,0.8)] border border-[rgba(199,167,108,0.4)] text-premium-primary1 hover:bg-premium-bg3 py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2"
            >
              <Phone size={16} className="text-premium-primary3" />
              Join Broadcast
            </a>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="border-t border-[rgba(199,167,108,0.15)] pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-premium-text3 text-xs font-light">
            © {new Date().getFullYear()} Sagar Fashion. All rights reserved. Wholesale B2B Only.
          </p>
          <button 
            onClick={scrollToTop}
            className="hover-target w-10 h-10 rounded-full bg-premium-bg1 border border-[rgba(199,167,108,0.3)] flex items-center justify-center text-premium-primary2 hover:bg-premium-primary1 hover:text-premium-bg1 hover:border-premium-primary1 transition-all"
          >
            <ArrowUp size={18} />
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
