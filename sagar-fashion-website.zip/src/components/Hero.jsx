import React from 'react';
import { motion, useScroll, useTransform, useMotionValue, useSpring } from 'framer-motion';
import { PlayCircle, ArrowRight, ShieldCheck, Gem } from 'lucide-react';
import { Link } from 'react-router-dom';

const Hero = () => {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 1000], [0, 150]);
  
  // 3D Tilt Effect
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const mouseXSpring = useSpring(x, { damping: 30, stiffness: 200 });
  const mouseYSpring = useSpring(y, { damping: 30, stiffness: 200 });
  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["5deg", "-5deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-5deg", "5deg"]);

  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    x.set(xPct);
    y.set(yPct);
  };
  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <section className="relative min-h-screen pt-24 pb-20 overflow-hidden flex items-center bg-gradient-to-br from-premium-bg1 via-premium-bg2 to-premium-bg3">
      
      {/* Background radial glow specifically for hero depth */}
      <div className="absolute top-[10%] left-[20%] w-[60vw] h-[60vw] rounded-full bg-premium-bg4/30 blur-[150px] pointer-events-none z-[-1]"></div>

      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
          
          {/* Left Content Area */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="flex-1 flex flex-col items-center lg:items-start text-center lg:text-left pt-10 lg:pt-0"
          >
            <div className="inline-flex items-center gap-2 mb-6 bg-[rgba(250,246,239,0.75)] border border-[rgba(199,167,108,0.45)] px-4 py-1.5 rounded-full shadow-sm">
              <ShieldCheck size={14} className="text-premium-primary2" />
              <span className="text-premium-primary2 text-[10px] font-bold uppercase tracking-[0.2em]">Luxury Wholesale Experience</span>
            </div>
            
            <h1 className="font-heading text-5xl sm:text-6xl lg:text-[5rem] font-bold text-premium-text1 leading-[1.1] tracking-tight mb-6 drop-shadow-sm">
              Premium Wholesale Suits <br className="hidden sm:block"/>
              <span className="bg-gradient-to-r from-premium-primary3 to-premium-accent2 bg-clip-text text-transparent italic font-normal pr-2">for Boutiques</span>
            </h1>
            
            <p className="text-premium-text2 text-lg md:text-xl font-light leading-relaxed max-w-xl mb-10">
              Fast-moving bridal, party wear, Anarkali, and Pakistani suits crafted for resellers, boutiques and shop owners across the globe.
            </p>

            <div className="flex flex-wrap items-center gap-3 mb-10 opacity-80 text-premium-primary2">
              <span className="text-[10px] uppercase tracking-wider font-semibold border-r border-premium-accent1/30 pr-3">Wholesale Only</span>
              <span className="text-[10px] uppercase tracking-wider font-semibold border-r border-premium-accent1/30 pr-3">MOQ 24 Pieces</span>
              <span className="text-[10px] uppercase tracking-wider font-semibold border-r border-premium-accent1/30 pr-3">135K+ Family</span>
              <span className="text-[10px] uppercase tracking-wider font-semibold">New Designs</span>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-5 w-full sm:w-auto">
              <button 
                onClick={() => document.getElementById('collection').scrollIntoView({ behavior: 'smooth' })}
                className="hover-target bg-premium-primary1 hover:bg-premium-primary2 text-premium-bg1 px-10 py-4 rounded-full font-bold tracking-wide flex items-center justify-center gap-3 group relative overflow-hidden shadow-luxury hover:shadow-[0_0_25px_rgba(199,167,108,0.28)] transition-all duration-500 w-full sm:w-auto"
              >
                <span className="relative z-10">Explore Collection</span>
                <ArrowRight size={18} className="relative z-10 group-hover:translate-x-2 transition-transform" />
              </button>
              
              <a 
                href="https://wa.me/917984572633" 
                target="_blank"
                rel="noreferrer"
                className="hover-target px-10 py-4 rounded-full font-bold tracking-wide flex items-center justify-center text-premium-primary1 bg-[rgba(250,246,239,0.8)] border border-premium-accent2 hover:bg-premium-bg3 transition-all duration-300 w-full sm:w-auto"
              >
                WhatsApp Inquiry
              </a>
            </div>
          </motion.div>

          {/* Right Imagery Collage with 3D Tilt */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.5, delay: 0.3, ease: [0.25, 1, 0.5, 1] }}
            className="flex-1 w-full relative perspective-1000 pt-10 lg:pt-0"
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            style={{ rotateX, rotateY }}
          >
            {/* Premium Arch Frame Image */}
            <div className="relative w-full max-w-[420px] mx-auto lg:ml-auto lg:mr-0 aspect-[3/4] rounded-t-full overflow-hidden border-2 border-[rgba(199,167,108,0.55)] shadow-[0_30px_80px_rgba(74,37,37,0.16)] group relative z-10">
              <div className="absolute inset-0 bg-premium-accent1/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
              <div className="w-full h-full rounded-t-full overflow-hidden relative z-10 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-premium-bg3 to-transparent">
                <img 
                  src="https://images.unsplash.com/photo-1595777457583-95e059d581b8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                  alt="Premium Bridal Collection" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1.5s] ease-out mix-blend-multiply opacity-90"
                />
              </div>
            </div>

            {/* Floating Mini Product Card */}
            <motion.div 
              style={{ y: y1 }}
              className="absolute -left-4 md:-left-16 top-1/4 w-32 md:w-40 bg-[rgba(250,246,239,0.88)] backdrop-blur-md rounded-2xl p-2 shadow-luxury border border-[rgba(199,167,108,0.35)] z-20 hidden sm:block"
            >
              <div className="aspect-[3/4] rounded-xl overflow-hidden mb-2">
                <img src="https://images.unsplash.com/photo-1610030469983-98e550d6193c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Detail" className="w-full h-full object-cover" />
              </div>
              <div className="px-1 pb-1">
                <p className="text-[9px] text-premium-primary1 font-bold uppercase tracking-wider">Premium Set</p>
                <div className="flex gap-1 mt-1">
                  <span className="w-2 h-2 rounded-full bg-premium-primary3"></span>
                  <span className="w-2 h-2 rounded-full bg-premium-accent1"></span>
                  <span className="w-2 h-2 rounded-full bg-[#1A1A1A]"></span>
                </div>
              </div>
            </motion.div>

            {/* Floating YouTube Badge */}
            <motion.a 
              href="#youtube"
              animate={{ y: [0, -12, 0] }}
              transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
              className="hover-target absolute -bottom-6 left-1/2 -translate-x-1/2 md:-translate-x-0 md:-left-8 bg-[rgba(250,246,239,0.88)] p-3 md:p-4 rounded-2xl flex items-center gap-3 hover:bg-white transition-colors z-30 cursor-none shadow-luxury w-[90%] md:w-64 border border-[rgba(199,167,108,0.35)]"
            >
              <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center text-white shrink-0 shadow-[0_0_15px_rgba(220,38,38,0.5)]">
                <PlayCircle size={24} />
              </div>
              <div>
                <h4 className="font-heading font-bold text-premium-primary1 text-sm md:text-base">135K+ Subscribers</h4>
                <p className="text-[9px] md:text-[10px] text-premium-text2 uppercase tracking-widest mt-0.5">Watch on YouTube</p>
              </div>
            </motion.a>

            <motion.div 
              animate={{ y: [0, 8, 0] }}
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut", delay: 1 }}
              className="absolute top-16 -right-2 md:-right-10 bg-[rgba(250,246,239,0.88)] p-3 rounded-2xl flex items-center gap-3 z-20 shadow-luxury border border-[rgba(199,167,108,0.35)]"
            >
              <div className="w-10 h-10 bg-premium-accent2 text-white rounded-full flex items-center justify-center shadow-inner">
                <Gem size={20} />
              </div>
              <div className="pr-2 hidden md:block">
                <p className="text-xs font-bold text-premium-primary1 uppercase tracking-wider">Pouch Packing</p>
                <p className="text-[9px] text-premium-text2 uppercase tracking-widest mt-0.5">Set-wise Box</p>
              </div>
            </motion.div>

          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default Hero;
