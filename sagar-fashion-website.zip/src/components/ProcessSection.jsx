import React from 'react';
import { Package, Shield, Star, Clock } from 'lucide-react';

const ProcessStep = ({ icon, title, desc, step }) => (
  <div className="flex flex-col items-center text-center max-w-xs relative group">
    <div className="w-20 h-20 rounded-full bg-premium-bg2 border border-[rgba(199,167,108,0.35)] flex items-center justify-center text-premium-primary2 mb-6 relative z-10 shadow-sm group-hover:bg-premium-primary1 group-hover:text-premium-bg1 transition-all duration-500">
      {icon}
      <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-premium-accent1 text-premium-primary1 text-xs font-bold flex items-center justify-center shadow-md border border-[rgba(250,246,239,0.5)]">
        {step}
      </div>
    </div>
    <h3 className="font-heading font-bold text-xl text-premium-text1 mb-3">{title}</h3>
    <p className="text-sm text-premium-text2 font-light">{desc}</p>
  </div>
);

const ProcessSection = () => {
  return (
    <section className="py-24 relative bg-premium-bg1 overflow-hidden">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=\'100\' height=\'100\' viewBox=\'0 0 100 100\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7z\' fill=\'%23D9B6A3\' fill-opacity=\'0.06\' fill-rule=\'evenodd\'/%3E%3C/svg%3E')]"></div>
      
      <div className="container mx-auto px-4 md:px-8 relative z-10">
        
        <div className="text-center max-w-3xl mx-auto mb-20">
          <span className="text-premium-primary4 font-bold tracking-[0.2em] uppercase text-[10px] mb-4 block">How it works</span>
          <h2 className="font-heading text-3xl md:text-5xl font-bold text-premium-text1 mb-6">Simple Wholesale Process</h2>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center md:items-start gap-12 relative max-w-5xl mx-auto">
          {/* Connecting Line */}
          <div className="hidden md:block absolute top-10 left-[10%] right-[10%] h-px bg-[rgba(199,167,108,0.35)] z-0"></div>
          
          <ProcessStep 
            step="1"
            icon={<Star size={32} />} 
            title="Select Designs" 
            desc="Add fast-selling suits to your bulk inquiry cart."
          />
          <ProcessStep 
            step="2"
            icon={<Shield size={32} />} 
            title="Confirm on WhatsApp" 
            desc="Send inquiry, get final invoice, and make secure payment."
          />
          <ProcessStep 
            step="3"
            icon={<Package size={32} />} 
            title="Premium Packing" 
            desc="Quality check and set-wise pouch packing."
          />
          <ProcessStep 
            step="4"
            icon={<Clock size={32} />} 
            title="Fast Dispatch" 
            desc="Sent via reliable courier or transport anywhere in the world."
          />
        </div>

      </div>
    </section>
  );
};

export default ProcessSection;
