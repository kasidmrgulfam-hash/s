import React from 'react';
import { PlayCircle, CheckCircle, Video } from 'lucide-react';
import ScrollReveal from '../components/ScrollReveal';

const VideoThumbnail = ({ src, title, views }) => (
  <div className="group cursor-none relative rounded-2xl overflow-hidden aspect-video border border-[rgba(199,167,108,0.35)] shadow-sm hover:shadow-card transition-all duration-500 bg-premium-bg2">
    <img src={src} alt={title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" loading="lazy" />
    <div className="absolute inset-0 bg-gradient-to-t from-premium-text1 via-transparent to-transparent opacity-50"></div>
    
    <div className="absolute inset-0 flex items-center justify-center">
      <div className="w-12 h-12 bg-premium-primary2/90 backdrop-blur-sm rounded-full flex items-center justify-center text-premium-bg1 group-hover:scale-110 group-hover:bg-premium-primary1 transition-all duration-300 shadow-md">
        <PlayCircle size={24} className="ml-1" />
      </div>
    </div>
    
    <div className="absolute bottom-3 left-3 right-3">
      <h4 className="text-white text-xs font-semibold line-clamp-1 mb-1">{title}</h4>
      <p className="text-premium-accent3 text-[10px]">{views}</p>
    </div>
  </div>
);

const YouTubeSection = () => {
  return (
    <section id="youtube" className="py-24 relative bg-gradient-to-b from-premium-bg2 to-premium-bg1">
      <div className="container mx-auto px-4 md:px-8 max-w-6xl">
        
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-premium-bg3 text-premium-primary2 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider mb-4 border border-[rgba(199,167,108,0.3)]">
            <Video size={16} /> Official Channel
          </div>
          <h2 className="font-heading text-3xl md:text-5xl font-bold text-premium-text1 mb-4">Trusted by 135K+ YouTube Family</h2>
          <p className="text-premium-text2 max-w-2xl mx-auto font-light">Watch our latest collections, customer reviews, and fabric details on YouTube before placing your bulk order.</p>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Main Featured Video */}
          <div className="lg:w-2/3">
            <div className="relative rounded-[2rem] overflow-hidden aspect-video border border-[rgba(199,167,108,0.45)] shadow-card group cursor-none">
              <img 
                src="https://images.unsplash.com/photo-1583391733958-d25e07fac661?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80" 
                alt="Main Feature" 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent"></div>
              
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-20 h-20 bg-premium-primary2/90 backdrop-blur-md rounded-full flex items-center justify-center text-premium-bg1 group-hover:scale-110 group-hover:bg-premium-primary1 transition-all duration-300 shadow-lg">
                  <PlayCircle size={40} className="ml-1" />
                </div>
              </div>

              <div className="absolute top-6 left-6 flex items-center gap-2 bg-premium-text1/50 backdrop-blur-md px-4 py-2 rounded-full text-white text-xs border border-white/10">
                <span className="w-2 h-2 rounded-full bg-premium-accent1 animate-pulse"></span>
                New Collection Weekly
              </div>
              
              <div className="absolute bottom-8 left-8 right-8">
                <h3 className="font-heading text-2xl md:text-3xl font-bold text-white mb-2">Premium Bridal & Party Wear Collection 2024</h3>
                <div className="flex items-center gap-4 text-premium-accent3 text-sm">
                  <span>1.2M Views</span>
                  <span>•</span>
                  <span>Sagar Fashion Wholesale</span>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar Videos */}
          <div className="lg:w-1/3 flex flex-col gap-6">
            <VideoThumbnail src="https://images.unsplash.com/photo-1610030469983-98e550d6193c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" title="Pakistani Suits Wholesale Market" views="850K Views" />
            <VideoThumbnail src="https://images.unsplash.com/photo-1595777457583-95e059d581b8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" title="Boutique Collection Direct from Factory" views="420K Views" />
            
            <a href="https://youtube.com" target="_blank" rel="noreferrer" className="hover-target mt-auto bg-[rgba(250,246,239,0.8)] border border-[rgba(199,167,108,0.35)] rounded-2xl p-6 flex flex-col items-center justify-center text-center hover:bg-white hover:shadow-card transition-all duration-300 h-full group">
              <Video size={32} className="text-premium-primary2 mb-3 group-hover:scale-110 group-hover:text-premium-primary1 transition-all" />
              <h4 className="font-bold text-premium-text1 mb-1">View All Videos</h4>
              <p className="text-xs text-premium-text2">Subscribe for latest updates</p>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};

export default YouTubeSection;
