import React, { useEffect, useState } from 'react';
import { motion, useSpring } from 'framer-motion';

const CustomCursor = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = useState(false);
  const [isDesktop, setIsDesktop] = useState(true);

  // Smooth springs for cursor follow
  const springConfig = { damping: 25, stiffness: 300, mass: 0.5 };
  const cursorX = useSpring(0, springConfig);
  const cursorY = useSpring(0, springConfig);
  // Slower, softer spring for the background glow
  const glowX = useSpring(0, { damping: 40, stiffness: 80, mass: 1 });
  const glowY = useSpring(0, { damping: 40, stiffness: 80, mass: 1 });

  useEffect(() => {
    // Check if device is desktop
    if (window.innerWidth < 1024 || 'ontouchstart' in window) {
      setIsDesktop(false);
      return;
    }

    const updateMousePosition = (e) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
      cursorX.set(e.clientX);
      cursorY.set(e.clientY);
      glowX.set(e.clientX);
      glowY.set(e.clientY);
    };

    const handleMouseOver = (e) => {
      if (
        e.target.tagName.toLowerCase() === 'button' ||
        e.target.tagName.toLowerCase() === 'a' ||
        e.target.closest('button') ||
        e.target.closest('a') ||
        e.target.classList.contains('hover-target')
      ) {
        setIsHovering(true);
      } else {
        setIsHovering(false);
      }
    };

    window.addEventListener('mousemove', updateMousePosition);
    window.addEventListener('mouseover', handleMouseOver);

    return () => {
      window.removeEventListener('mousemove', updateMousePosition);
      window.removeEventListener('mouseover', handleMouseOver);
    };
  }, [cursorX, cursorY, glowX, glowY]);

  if (!isDesktop) return null;

  return (
    <>
      {/* Soft trailing muted champagne glow */}
      <motion.div
        className="fixed top-0 left-0 w-40 h-40 bg-[rgba(199,167,108,0.16)] rounded-full blur-[50px] pointer-events-none z-[9997]"
        style={{
          x: glowX,
          y: glowY,
          translateX: '-50%',
          translateY: '-50%',
        }}
      />
      
      {/* Inner precise dot */}
      <motion.div
        className="fixed top-0 left-0 w-1.5 h-1.5 bg-premium-primary1 rounded-full pointer-events-none z-[9999]"
        style={{
          x: mousePosition.x,
          y: mousePosition.y,
          translateX: '-50%',
          translateY: '-50%',
        }}
        animate={{
          scale: isHovering ? 0 : 1,
        }}
        transition={{ type: 'tween', ease: 'backOut', duration: 0.15 }}
      />
      
      {/* Outer reactive ring */}
      <motion.div
        className="fixed top-0 left-0 w-10 h-10 border border-[rgba(74,37,37,0.45)] rounded-full pointer-events-none z-[9998] flex items-center justify-center"
        style={{
          x: cursorX,
          y: cursorY,
          translateX: '-50%',
          translateY: '-50%',
        }}
        animate={{
          scale: isHovering ? 1.5 : 1,
          backgroundColor: isHovering ? 'rgba(184, 149, 95, 0.25)' : 'transparent',
          borderColor: isHovering ? 'rgba(74, 37, 37, 0.2)' : 'rgba(74, 37, 37, 0.45)',
        }}
        transition={{ type: 'tween', ease: 'easeOut', duration: 0.2 }}
      />
    </>
  );
};

export default CustomCursor;
