import React from 'react';
import { useCart } from '../context/CartContext';
import { X, Plus, Minus, Trash2, Phone, ShoppingBag, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import ImageWithFallback from './ImageWithFallback';

const CartDrawer = () => {
  const { cart, removeFromCart, updateQuantity, totalSets, isCartOpen, setIsCartOpen } = useCart();

  const handleWhatsAppCheckout = () => {
    let message = "Hello Sagar Fashion,\nI want to place a bulk order. Here is my requirement list:\n\n";
    
    cart.forEach((item, index) => {
      message += `${index + 1}. *${item.name}*\n`;
      message += `   Sets: ${item.quantity} (${item.quantity * 4} Pieces)\n`;
      message += `   Expected Price: ${item.priceRange}\n\n`;
    });

    message += `*Total Sets:* ${totalSets}\n`;
    message += `*Total Pieces:* ${totalSets * 4}\n\n`;
    message += "Please confirm availability and share the final wholesale invoice.\n";
    message += "Business Name: \nCity: ";

    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/917984572633?text=${encodedMessage}`, '_blank');
  };

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsCartOpen(false)}
            className="fixed inset-0 bg-black/30 backdrop-blur-sm z-[100]"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 h-full w-full sm:w-[450px] bg-premium-bg1 shadow-[-20px_0_40px_rgba(74,37,37,0.1)] z-[101] flex flex-col border-l border-[rgba(199,167,108,0.35)]"
          >
            {/* Header */}
            <div className="p-6 border-b border-[rgba(199,167,108,0.2)] flex items-center justify-between bg-white/50 backdrop-blur-md">
              <div className="flex items-center gap-3">
                <ShoppingBag className="text-premium-primary3" size={24} />
                <h2 className="font-heading font-bold text-2xl text-premium-text1">Bulk Inquiry</h2>
              </div>
              <button 
                onClick={() => setIsCartOpen(false)}
                className="hover-target p-2 text-premium-text2 hover:text-premium-primary1 hover:bg-premium-bg3 rounded-full transition-colors"
              >
                <X size={24} />
              </button>
            </div>

            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-4">
              {cart.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-premium-text3 space-y-4">
                  <ShoppingBag size={64} className="opacity-30 text-premium-accent1" />
                  <p className="font-medium text-lg">Your inquiry list is empty</p>
                  <button 
                    onClick={() => setIsCartOpen(false)}
                    className="mt-4 text-premium-primary2 font-semibold hover:text-premium-primary1 underline"
                  >
                    Browse Collection
                  </button>
                </div>
              ) : (
                cart.map((item) => (
                  <motion.div 
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    key={item.id} 
                    className="flex gap-4 p-4 bg-white border border-[rgba(199,167,108,0.2)] rounded-2xl shadow-sm hover:shadow-md transition-shadow"
                  >
                    <div className="w-24 h-32 rounded-xl overflow-hidden bg-premium-bg2 shrink-0 border border-[rgba(199,167,108,0.1)]">
                      <ImageWithFallback src={item.image} alt={item.name} />
                    </div>
                    
                    <div className="flex-1 flex flex-col py-1">
                      <div className="flex justify-between items-start mb-1">
                        <h3 className="font-heading font-bold text-premium-text1 line-clamp-2 leading-snug">{item.name}</h3>
                        <button 
                          onClick={() => removeFromCart(item.id)}
                          className="hover-target text-premium-text3 hover:text-red-500 p-1"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                      
                      <p className="text-[11px] text-premium-primary4 font-semibold mb-auto uppercase tracking-wider">{item.category}</p>
                      
                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center bg-premium-bg2 border border-[rgba(199,167,108,0.3)] rounded-lg overflow-hidden">
                          <button 
                            onClick={() => updateQuantity(item.id, -1)}
                            className="px-3 py-1.5 hover:bg-premium-bg3 text-premium-text1 transition-colors"
                          >
                            <Minus size={14} />
                          </button>
                          <span className="px-3 py-1.5 font-bold text-sm min-w-[32px] text-center text-premium-text1">{item.quantity}</span>
                          <button 
                            onClick={() => updateQuantity(item.id, 1)}
                            className="px-3 py-1.5 hover:bg-premium-bg3 text-premium-text1 transition-colors"
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                        <span className="text-[10px] bg-premium-bg4/30 text-premium-primary1 font-bold px-2 py-1 rounded border border-premium-accent1/30">
                          {item.quantity * 4} Pcs
                        </span>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>

            {/* Footer Summary */}
            {cart.length > 0 && (
              <div className="p-6 bg-white border-t border-[rgba(199,167,108,0.2)] shadow-[0_-10px_30px_rgba(74,37,37,0.04)] relative z-10">
                <div className="flex justify-between items-center mb-4 text-sm font-semibold">
                  <span className="text-premium-text2">Total Sets:</span>
                  <span className="text-xl text-premium-text1 font-bold">{totalSets} Sets</span>
                </div>
                <div className="flex justify-between items-center mb-6 text-sm font-semibold">
                  <span className="text-premium-text2">Total Pieces (4 pcs/set):</span>
                  <span className="text-xl text-premium-primary2 font-bold">{totalSets * 4} Pieces</span>
                </div>

                {totalSets < 6 && (
                  <div className="flex items-start gap-2 mb-6 p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-xs">
                    <AlertCircle size={16} className="shrink-0 mt-0.5" />
                    <p>Minimum Order Quantity is 6 Sets (24 Pieces). Please add {6 - totalSets} more sets to proceed.</p>
                  </div>
                )}

                <button
                  onClick={handleWhatsAppCheckout}
                  disabled={totalSets < 6}
                  className={`hover-target w-full flex items-center justify-center gap-2 py-4 rounded-xl font-bold uppercase tracking-wider transition-all duration-300 shadow-md
                    ${totalSets >= 6 
                      ? 'bg-premium-primary1 hover:bg-premium-primary2 text-premium-bg1 hover:shadow-luxury hover:scale-[1.02]' 
                      : 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}
                >
                  <Phone size={18} />
                  Send Inquiry on WhatsApp
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default CartDrawer;
