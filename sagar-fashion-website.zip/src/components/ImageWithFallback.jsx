import React, { useState } from 'react';

const ImageWithFallback = ({ src, alt, className, style }) => {
  const [hasError, setHasError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  if (hasError || !src) {
    return (
      <div 
        className={`flex items-center justify-center bg-premium-bg3 text-premium-primary2 font-heading italic relative overflow-hidden ${className}`}
        style={style}
      >
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=\'80\' height=\'80\' viewBox=\'0 0 100 100\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M50 0C55 20 80 45 100 50C80 55 55 80 50 100C45 80 20 55 0 50C20 45 45 20 50 0Z\' fill=\'%23D9B6A3\' fill-opacity=\'0.15\'/%3E%3C/svg%3E')] bg-center bg-no-repeat bg-[length:150px] opacity-60"></div>
        <span className="relative z-10 px-4 text-center">Sagar Fashion Collection</span>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden ${className}`} style={style}>
      {!isLoaded && (
        <div className="absolute inset-0 bg-premium-bg2 animate-pulse z-10"></div>
      )}
      <img
        src={src}
        alt={alt}
        className={`w-full h-full object-cover transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
        onLoad={() => setIsLoaded(true)}
        onError={() => setHasError(true)}
        loading="lazy"
      />
    </div>
  );
};

export default ImageWithFallback;
