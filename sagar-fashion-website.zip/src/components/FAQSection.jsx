import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const faqs = [
  {
    question: "Do you sell single pieces?",
    answer: "No, we are strictly a B2B wholesale supplier. We only sell in full sets (1 design = 4 colors = 4 pieces). Our minimum order quantity is 6 sets (24 pieces)."
  },
  {
    question: "Is Cash on Delivery (COD) available?",
    answer: "No, we only accept 100% prepaid orders via Bank Transfer, NEFT, RTGS, or UPI. Since we deal in bulk wholesale, COD is not feasible."
  },
  {
    question: "Do you ship internationally?",
    answer: "Yes, we ship globally. Shipping charges will be calculated based on the weight of your parcel and the destination country."
  },
  {
    question: "What is your return policy?",
    answer: "We strictly check all pieces before dispatch. Returns are only accepted if there is a major manufacturing defect or damage during transit, provided you share a continuous parcel opening video."
  },
  {
    question: "How can I get daily updates?",
    answer: "Subscribe to our YouTube channel 'Sagar Fashion Surat' and save our WhatsApp number to view our daily catalog updates on WhatsApp Status."
  }
];

const FAQSection = () => {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <section className="py-24 relative bg-premium-bg1">
      <div className="container mx-auto px-4 md:px-8 max-w-4xl">
        
        <div className="text-center mb-16">
          <span className="text-premium-primary4 font-bold tracking-[0.2em] uppercase text-[10px] mb-4 block">Support</span>
          <h2 className="font-heading text-3xl md:text-5xl font-bold text-premium-text1 mb-6">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div 
              key={index} 
              className={`border rounded-2xl overflow-hidden transition-all duration-300 ${openIndex === index ? 'border-premium-accent1 bg-white shadow-card' : 'border-[rgba(199,167,108,0.25)] bg-[rgba(255,253,248,0.8)] hover:bg-white'}`}
            >
              <button 
                className="w-full px-6 py-5 flex items-center justify-between text-left hover-target"
                onClick={() => setOpenIndex(openIndex === index ? -1 : index)}
              >
                <span className={`font-bold text-lg ${openIndex === index ? 'text-premium-primary2' : 'text-premium-text1'}`}>
                  {faq.question}
                </span>
                <ChevronDown 
                  className={`text-premium-primary4 transition-transform duration-300 ${openIndex === index ? 'rotate-180' : ''}`} 
                  size={20} 
                />
              </button>
              
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="px-6 pb-5 text-premium-text2 font-light leading-relaxed border-t border-[rgba(199,167,108,0.15)] pt-4">
                      {faq.answer}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

export default FAQSection;
